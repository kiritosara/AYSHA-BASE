const fs = require('fs')
const P = require('pino')
const cfonts = require('cfonts')
const chalk = require('chalk')

const {
default:
makeWASocket,
DisconnectReason,
Browsers,BufferJSON, 
useMultiFileAuthState
} = require ('@WhiskeySockets/baileys')

banner = cfonts.render(('AYSHA|BASE'),
{
 font: "block" ,
 align: "center",
 gradient: ["magenta","blue"]
})
console.log(banner.string)

async function LigaBot() {
  
const { 
state, saveCreds 
} = await useMultiFileAuthState('./files/qrcode')

const Ay = makeWASocket({
auth: state,
syncFullHistory: true,
printQRInTerminal: true,
logger: P({ level: 'silent' }),
browser: Browsers.macOS('DELUX🎭')
})

Ay.ev.on('creds.update',saveCreds)
Ay.ev.on('connection.update', (update) => {
const {
connection, lastDisconnect
} = update

if(connection === 'close') {
const shouldReconnect = 
(lastDisconnect)?.output?.statusCode
!== DisconnectReason.loggedOut

console.log(
'Perda de coneção irei reconectar:',
lastDisconnect.error,
`Reconectando...`,
shouldReconnect
)

if(shouldReconnect) { LigaBot() }

} else if(connection === 'open') {

console.log(`AYSHA-BASE PRONTA PARA HACKEAR 😈, CONECTADA!!!`)
}})
//})


return Ay 
}

  

module.exports = LigaBot;