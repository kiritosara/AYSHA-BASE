const menu = (pushName, prefixo) => { 

// NÃO APAGUE ESSE ${prefixo}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DA CONFIGURAÇÃO.JS, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

//
// Pode Alterar Todo o Menu 
//  [💧] AYSHA IMAPCT
return `
╔═══════ ═══════╕
┣❅➺olá ${pushName}
╚══════ ════════╛
❢◥ ▬▬▬▬▬ 🌸▬▬▬▬▬ ◤❢
║║️️✿⊰➺ ${prefixo}ban
║║️️✿⊰➺ ${prefixo}kick
║║️️✿⊰➺ ${prefixo}promover
║║️️✿⊰➺ ${prefixo}rebaixar
║║️️✿⊰➺ MENUS
║║️️✿⊰➺ ${prefixo}menugame
║║️️✿⊰➺ ${prefixo}menuadm
║║️️✿⊰➺ ${prefixo}play
║║️️✿⊰➺ só base mesmo
❢◥ ▬▬▬▬▬ 🌸 ▬▬▬▬▬ ◤❢ `


}
exports.menu = menu
//// NÃO APAGUE ESSE ` `
/// ( CASO NÃO QUEIRA ERROS ) \\\\



const menu2 = (pushName, prefixo) => { 

// NÃO APAGUE ESSE ${prefixo}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DA CONFIGURAÇÃO.JS, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

return `
❢◥ ▬▬▬▬▬🌸▬▬▬▬▬ ◤❢
️║║️️✿⊰➺ ${prefixo} eudevo
║║️️✿⊰➺ ${prefixo}chance
║║️️✿⊰➺ ${prefixo}gado
║║️️✿⊰➺ ${prefixo}feio
║║️️✿⊰➺ ${prefixo}gay
║║️️✿⊰➺ ${prefixo}agua
║║️️✿⊰➺ ${prefixo}money
║║️️✿⊰➺ ${prefixo}milk
║║️️✿⊰➺ ${prefixo}pescar
║║️️✿⊰➺ ${prefixo}minerar
║║️️✿⊰➺ ${prefixo}cassino
║║️️✿⊰➺ ${prefixo}frioecalculista
║║️️✿⊰➺ ${prefixo}traduzirInvertido
║║️️✿⊰➺ ${prefixo}rankopunheteiros
║║️️✿⊰➺ ${prefixo}invertertexto
║║️️✿⊰➺ ${prefixo}ranknazista
║║️️✿⊰➺ ${prefixo}caçatesouro
║║️️✿⊰➺ ${prefixo}rankgado
║║️️✿⊰➺ ${prefixo}rankcorno
║║️️✿⊰➺ ${prefixo}rankputas
║║️️✿⊰➺ ${prefixo}rankgostoso
║║️️✿⊰➺ ${prefixo}rankgostosa
║║️️✿⊰➺ ${prefixo}rankpau
║║️️✿⊰➺ ${prefixo}rankgay
║║️️✿⊰➺ ${prefixo}gostosa
║║️️✿⊰➺ ${prefixo}gostoso
║║️️✿⊰➺ ${prefixo}nazista
║║️️✿⊰➺ ${prefixo}perfil
║║️️✿⊰➺ ${prefixo}desafio
║║️️✿⊰➺ ${prefixo}metadinha
║║️️✿⊰➺ ${prefixo}caulcular
║║️️✿⊰➺ ${prefixo}dogolpe
║║️️✿⊰➺ ${prefixo}vergonha
║║️️✿⊰➺ ${prefixo}gadometro
║║️️✿⊰➺ ${prefixo}nivelgado
║║️️✿⊰➺ ${prefixo}azarados
║║️️✿⊰➺ ${prefixo}missao
║║️️✿⊰➺ ${prefixo}perfil
║║️️✿⊰➺ ${prefixo}lindo
║║️️✿⊰➺ ${prefixo}linda
║║️️✿⊰➺ ${prefixo}pau
║║️️✿⊰➺ ${prefixo}s/n
║║️️✿⊰➺ ${prefixo}ppp?
║║️️✿⊰➺ ${prefixo}ppt?
║║️️✿⊰➺ ${prefixo}sebosa
║║️️✿⊰➺ ${prefixo}seboso
║║️️✿⊰➺ ${prefixo}abraçar
║║️️✿⊰➺ ${prefixo}beijo
║║️️✿⊰➺ ${prefixo}tapa
║║️️✿⊰➺ ${prefixo}chute
║║️️✿⊰➺ ${prefixo}sorteio
║║️️✿⊰➺ ${prefixo}matar
║║️️✿⊰➺ ${prefixo}chifre
║║️️✿⊰➺  alguns comandos nao foram add!!!
❢◥ ▬▬▬▬▬🌸▬▬▬▬▬ ◤❢`
}
exports.menu2 = menu2


const menu3 = (prefixo, pushName) => { 

// NÃO APAGUE ESSE ${prefixo}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DA CONFIGURAÇÃO.JS, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

return `


❢◥ ▬▬▬▬▬🌸▬▬▬▬▬ ◤❢
┣❅➺ 👺⃟ⲘⲈⴄⴑ-ƊϴИϴ⃟👺
❢◥ ▬▬▬▬▬🌸▬▬▬▬▬ ◤❢
║║️️✿⊰➺ ${prefixo}sai
║║️️✿⊰➺ ${prefixo}nuke
║║️️✿⊰➺ ${prefixo}config_gp
║║️️✿⊰➺ ${prefixo}tirarftgp
║║️️✿⊰➺ ${prefixo}allgps
║║️️✿⊰➺ ${prefixo}listagp
║║️️✿⊰➺ ${prefixo}block
║║️️✿⊰➺ ${prefixo}novoqr
║║️️✿⊰➺ ${prefixo}entrar
║║️️✿⊰➺ ${prefixo}unblock
║║️️✿⊰➺ ${prefixo}reiniciar
║║️️✿⊰➺ ${prefixo}sermembro
║║️️✿⊰➺ ${prefixo}cheguei/seradm
║║️️✿⊰➺ ${prefixo}sairgrupos
║║️️✿⊰➺ ${prefixo}apresentar
║║️️✿⊰➺ ${prefixo}rebaixar
❢◥ ▬▬▬▬▬🌸▬▬▬▬▬ ◤❢`

}
exports.menu3 = menu3





